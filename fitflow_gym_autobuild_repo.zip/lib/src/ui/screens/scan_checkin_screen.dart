import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class ScanCheckinScreen extends StatefulWidget {
  const ScanCheckinScreen({super.key});

  @override
  State<ScanCheckinScreen> createState() => _ScanCheckinScreenState();
}

class _ScanCheckinScreenState extends State<ScanCheckinScreen> {
  String? scannedCode;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scan Check-in')),
      body: Column(
        children: [
          Expanded(
            child: MobileScanner(
              onDetect: (barcodeCapture) {
                final code = barcodeCapture.barcodes.first.rawValue;
                setState(() => scannedCode = code);
              },
            ),
          ),
          if (scannedCode != null)
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text('Scanned: \$scannedCode'),
            ),
        ],
      ),
    );
  }
}
