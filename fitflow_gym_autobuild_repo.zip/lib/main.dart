import 'package:flutter/material.dart';
import 'src/ui/screens/scan_checkin_screen.dart';

void main() {
  runApp(const FitFlowApp());
}

class FitFlowApp extends StatelessWidget {
  const FitFlowApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'FitFlow Gym',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const ScanCheckinScreen(),
    );
  }
}
